"""Django project configuration."""
