from django import forms
from django.contrib.auth import get_user_model
from database.models import Membership
from database.models import ACCENTS, STATUSES, Ticket, Workspace


class TicketForm(forms.ModelForm):
    version = forms.IntegerField(required=False, widget=forms.HiddenInput)
    guest_count = forms.IntegerField(required=False, min_value=1, max_value=12, initial=1, widget=forms.NumberInput(attrs={"min": "1", "max": "12"}))
    class Meta:
        model = Ticket
        fields = ("title", "cat_name", "description", "category", "guest_count", "session_time", "status", "priority", "due_date", "assignee", "requester_email")
        widgets = {
            "description": forms.Textarea(attrs={"rows": 5}),
            "due_date": forms.DateInput(attrs={"type": "date"}),
            "guest_count": forms.NumberInput(attrs={"min": "1", "max": "12"}),
        }

    def __init__(self, *args, workspace=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["title"].label = "Customer name"
        self.fields["title"].help_text = "Name of the person making the reservation."
        self.fields["cat_name"].label = "Cat name"
        self.fields["cat_name"].help_text = "Which resident cat would the guest like to meet? Optional."
        self.fields["guest_count"].label = "Number of guests"
        self.fields["guest_count"].help_text = "Maximum 12 guests per reservation."
        self.fields["session_time"].label = "Preferred session"
        self.fields["session_time"].help_text = "Example: 10:00 AM, 1:00 PM, or 4:00 PM."
        self.fields["category"].label = "Visit type"
        self.fields["status"].label = "Reservation status"
        self.fields["priority"].label = "Preparation priority"
        self.fields["due_date"].label = "Visit date"
        self.fields["assignee"].label = "Staff host"
        self.fields["description"].label = "Special requests / notes"
        self.fields["requester_email"].label = "Customer email"
        members = Membership.objects.filter(workspace=workspace, role__in=["owner", "manager", "agent"]).values("user_id")
        self.fields["assignee"].queryset = get_user_model().objects.filter(id__in=members).order_by("first_name", "username")
        self.fields["assignee"].label_from_instance = lambda user: user.get_full_name() or user.get_username()
        self.fields["assignee"].empty_label = "Unassigned"
        if self.instance.pk:
            self.fields["version"].initial = self.instance.version
            self.fields["version"].required = True

    def clean_guest_count(self):
        value = self.cleaned_data.get("guest_count")
        if value is None:
            return 1
        if not 1 <= value <= 12:
            raise forms.ValidationError("A reservation must have between 1 and 12 guests.")
        return value

    def clean_title(self):
        value = self.cleaned_data["title"].strip()
        if not value:
            raise forms.ValidationError("Give this item a title.")
        return value

    def clean_category(self):
        value = self.cleaned_data["category"].strip()
        if not value:
            raise forms.ValidationError("Enter a category.")
        return value


class PreferencesForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Keep the existing stored key so current databases need no migration.
        self.fields["accent"].choices = [("teal", "Dashboard purple (default)"), ("violet", "Violet"), ("forest", "Forest"), ("clay", "Clay")]

    class Meta:
        model = Workspace
        fields = ("name", "accent")

    def clean_name(self):
        value = self.cleaned_data["name"].strip()
        if not value:
            raise forms.ValidationError("Enter a workspace name.")
        return value


class MoveForm(forms.Form):
    status = forms.ChoiceField(choices=STATUSES)


class WorkflowForm(forms.Form):
    operation = forms.ChoiceField(choices=[
        ("append", "Add to end · append"), ("prepend", "Add to start · prepend"),
        ("insert_at", "Insert at position · insert_at"), ("remove_at", "Remove at position · remove_at"),
        ("remove", "Remove first matching step · remove"), ("get", "Read at position · get"),
        ("index_of", "Find first position · index_of"),
    ])
    value = forms.CharField(max_length=80, required=False)
    index = forms.IntegerField(min_value=0, required=False)

    def clean(self):
        data = super().clean()
        op = data.get("operation")
        if op in {"append", "prepend", "insert_at", "remove", "index_of"} and not data.get("value", "").strip():
            self.add_error("value", "This operation needs a value.")
        if op in {"insert_at", "remove_at", "get"} and data.get("index") is None:
            if "index" not in self.errors:
                self.add_error("index", "This operation needs an index.")
        return data


class CommentForm(forms.Form):
    body = forms.CharField(max_length=3000, widget=forms.Textarea(attrs={"rows": 4, "placeholder": "Add context, a handoff, or a progress update…"}), label="Team note")
